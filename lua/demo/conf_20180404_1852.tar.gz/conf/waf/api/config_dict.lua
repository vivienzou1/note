
---- config_dict 操作 增删该查
--   包含模块
--   base realIpFrom_Mod deny_Msg [序号非数字]
--   uri_Mod header_Mod useragent_Mod cookie_Mod args_Mod post_Mod
--   network_Mod replace_Mod host_method_Mod rewrite_Mod app_Mod referer_Mod

-- 所有模块及参数： http://wafdev.soyoung.com:5460/api/config_dict?action=get&mod=all_mod
-- 所有模块： http://wafdev.soyoung.com:5460/api/config_dict?action=get&mod=
-- 获得指定模块： http://wafdev.soyoung.com:5460/api/config_dict?action=get&mod=rewrite_Mod


--[[
1、修改某个规则：
	a、涉及数据格式兼容处理，执行先删除，然后再添加，即全量覆盖
		http://wafdev.soyoung.com:5460/api/config_dict?action=set&mod=rewrite_Mod&value=[{%22state%22:%22on%22,%22action%22:%22set_cookie%22,%22uri%22:[%22^\/rewrite$%22,%22jio%22],%22set_cookie%22:[%22soyoungwkejrmkdsjw2332kjs3lk001%22,%22soyoung%22],%22hostname%22:[%22172.16.16.183%22,%22%22]},{%22state%22:%22on%22,%22action%22:%22set_cookie%22,%22uri%22:[%22^\/rewrite$%22,%22jio%22],%22set_cookie%22:[%22soyoungwkejrmkdsjw2332kjs3lk002%22,%22soyoung%22],%22hostname%22:[%22172.16.16.184%22,%22%22]}]

	b、执行上面的修改整个规则之后，然后调用：
		http://wafdev.soyoung.com:5460/api/config?action=save&mod=all_Mod
	c、将刚刚修改的配置文件写到本地磁盘，然后执行：
		http://wafdev.soyoung.com:5460/api/config?action=reload
		将本地规则加载到内存中


2、删除某个模块的规则,id是从1开始的，及第几个规则：
	a、删除
		http://wafdev.soyoung.com:5460/api/config_dict?action=del&mod=rewrite_Mod&id=2
	然后执行上面的b、c两步操作

--]]

local cjson_safe = require "cjson.safe"
local optl = require("optl")

local get_argsByName = optl.get_argsByName

local _action = get_argsByName("action")
local _mod = get_argsByName("mod")
local _id = get_argsByName("id")
local _value = get_argsByName("value")
local _value_type = get_argsByName("value_type")

local config_dict = ngx.shared.config_dict
local config = cjson_safe.decode(config_dict:get("config")) or {}
local config_base = config.base or {}


local _code = "ok"
if _action == "get" then

	if _mod == "all_mod" then
		local tmp_config = {}
		for k,v in pairs(config) do
			tmp_config[k] = cjson_safe.encode(v)
		end
		tmp_config.code = _code
		optl.sayHtml_ext(tmp_config)

	elseif _mod == "" then-- 显示所有 keys 的 name
		local tmp_config = {}
		for k,v in pairs(config) do
			table.insert(tmp_config,k)
		end
		tmp_config.code = _code
		optl.sayHtml_ext(tmp_config)

	else
		local _tb = config[_mod]
		if _tb == nil then optl.sayHtml_ext({code="error",msg="mod is Non-existent"}) end
		if _id == "" then
			_tb.state = config_base[_mod]
			_tb.code = _code
			optl.sayHtml_ext(_tb)

		elseif _id == "count_id" then
			local cnt = 0
			for k,v in pairs(_tb) do
				cnt = cnt+1
			end
			optl.sayHtml_ext({code=_code,count_id=cnt})
		else
			--- realIpFrom_Mod 和 base 和 denyHost_Mod 特殊处理
			if _mod ~= "realIpFrom_Mod" and _mod ~= "base" and _mod ~= "denyMsg" then
				_id = tonumber(_id) or 1
			end
			optl.sayHtml_ext({code=_code,msg=_tb[_id]})
		end

	end

elseif _action == "set" then

	local _tb = config[_mod]
	if _tb == nil then optl.sayHtml_ext({code="error",msg="mod is Non-existent"}) end

	-- 整体set
	local tmp_value = cjson_safe.decode(_value)--将value参数的值 转换成table
	if type(tmp_value) == "table" then
		local _old_value = _tb
		config[_mod] = tmp_value
		local re = config_dict:replace("config",cjson_safe.encode(config))--将对应mod整体进行替换
		if re ~= true then
			_code = "error"
			optl.sayHtml_ext({code=_code,msg="replace error"})
		end
		config_dict:incr("config_version",1)
		optl.sayHtml_ext({code=_code,old_value=_old_value,new_value=tmp_value})
	else
		optl.sayHtml_ext({code="error",msg="value to json error"})
	end

elseif _action == "del" then

	-- 判断mod 是否存在
	local _tb = config[_mod]
	if _tb == nil then optl.sayHtml_ext({code="error",msg="mod is Non-existent"}) end

	if _mod == "realIpFrom_Mod" or _mod == "denyMsg" then
		if _tb[_id] == nil then
			optl.sayHtml_ext({code="error",msg="id is Non-existent"})
		else
			config[_mod][_id] = nil
			local re = config_dict:replace("config",cjson_safe.encode(config))
			if re ~= true then
				_code = "error"
				optl.sayHtml_ext({code=_code,msg="replace error"})
			end
			config_dict:incr("config_version",1)
			optl.sayHtml_ext({code=_code,mod=_mod,id=_id})
		end
	elseif _mod == "base" then
		optl.sayHtml_ext({code="error",msg="base does not support del"})
	else
		_id = tonumber(_id)
		if _id == nil then
			optl.sayHtml_ext({code="error",msg="_id is not number"})
		else
			local rr = table.remove(config[_mod],_id)
			if rr == nil then
				optl.sayHtml_ext({code="error",msg="id is Non-existent"})
			else
				local re = config_dict:replace("config",cjson_safe.encode(config))
				if re ~= true then
					_code = "error"
					optl.sayHtml_ext({code=_code,msg="replace error"})
				end
				config_dict:incr("config_version",1)
				optl.sayHtml_ext({code=_code,mod=_mod,id=_id})
			end
		end
	end

else
	optl.sayHtml_ext({code="error",msg="action error"})
end
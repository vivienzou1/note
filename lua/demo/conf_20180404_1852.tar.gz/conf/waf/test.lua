
local optl = require("optl")



--[[

act = "test"
local xy_token = "";
if act == "test" then
    xy_token = "_xy_"..act
end
ngx.header.content_type = "text/html"
ngx.say(xy_token,host)
ngx.exit(ngx.HTTP_FORBIDDEN)

-- 获取ip
local ip1 = ngx.var.remote_addr
--通过设置nginx头信息获取
local headers = ngx.req.get_headers()
local ip2 = headers["X-REAL-IP"] or headers["X_FORWARDED_FOR"] or ngx.var.remote_addr or "0.0.0.0"
local ip3 = headers["Host"]
local ip4 = headers["X_Forwarded_For"]

ngx.header.content_type = "text/html"
--ngx.say(ngx.req.get_headers()["Host"])
ngx.say("ip1<hr>",ip1,"<hr>ip2<hr>",ip2,"<hr>ip3<hr>",ip3,"<hr>ip4<hr>",get_client_ip())
ngx.exit(ngx.HTTP_FORBIDDEN)
--]]

-- redis 连接 (用法参考：https://github.com/openresty/lua-resty-redis/blob/master/README.markdown#redis-authentication)
local redis = require "resty.redis"
local red = redis:new()
red:set_timeout(2000) -- 2 sec

local ok, err = red:connect("172.16.16.4",19000)
if not ok then
    ngx.say("redis failed to connect: ", err)
    return
end
local count, err = red:get_reused_times()

-- 授权，redis有密码
local redis_pwd = ""
if 0 == count then
    if redis_pwd ~= "" then
        local ok, err = red:auth(redis_mod.Password)
        if not ok then
            ngx.say("failed to auth1: ", err)
            return
        end
    end
elseif err then
    ngx.say("failed to auth2: ", err)
    return
end

red:set("soyoung_test_redis_key", "this is redis value")
local xy_val = red:get("soyoung_test_redis_key")

ngx.header.content_type = "text/html"
ngx.say("type \t",type(xy_val),"<hr>",xy_val)
ngx.exit(ngx.HTTP_FORBIDDEN)

--test
red:init_pipeline()
red:set("cat", "Marry")
red:set("horse", "Bob")
red:get("cat")
red:get("horse")
local results, err = red:commit_pipeline()
if not results then
    ngx.say("failed to commit the pipelined requests: ", err)
    return
end
ngx.exit(ngx.HTTP_FORBIDDEN)

ngx.header.content_type = "text/html"
ngx.say(77888)
ngx.exit(ngx.HTTP_FORBIDDEN)

--set
ok, err = red:set("dog", "an animal")
if not ok then
    ngx.say("failed to set dog: ", err)
    return
end
ngx.say("set result: ", ok)

--get
local res, err = red:get("dog")
if not res then
    ngx.say("failed to get dog: ", err)
    return
end
-- 结果判断
if res == ngx.null then
    ngx.say("dog not found.")
    return
end

-- 连接池大小是100个，并且设置最大的空闲时间是 10 秒
local ok, err = red:set_keepalive(10000, 100)
if not ok then
    local _msg = "failed to set keepalive: "..tostring(err)
    sayHtml_ext({code="error",msg=_msg})
    --ngx.say("failed to set keepalive: ", err)
    return
end
-- test




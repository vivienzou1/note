local _worker_count = ngx.worker.count()
local _worker_id = ngx.worker.id()

local ngx_shared = ngx.shared
local require = require
local ipairs = ipairs
local ngx_log = ngx.log
local ngx_ERR = ngx.ERR
local ngx_thread = ngx.thread
local timer_at = ngx.timer.at
local timer_every = ngx.timer.every
local config_dict = ngx_shared.config_dict
local cjson_safe = require "cjson.safe"

local handler
local handler_all
local handler_zero

local config_base


-- dict 清空过期内存
local function flush_expired_dict()
	local dict_list = {"token_dict","count_dict","config_dict","host_dict","ip_dict","limit_ip_dict"}
	for _,v in ipairs(dict_list) do
		ngx_shared[v]:flush_expired()
	end
end

-- 拉取config_dict配置数据(redis)

-- 推送config_dict、host_dict、count_dict到redis

-- 推送count_dict统计、计数等(redis)

-- 保存config_dict、host_dict到本机文件

-- 定时更新配置文件

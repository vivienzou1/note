local cjson_safe = require "cjson.safe"
local optl = require("optl")
local JSON = require("xy_json")

-- redis使用
local redis = require "redis_iresty"
local red = redis:new()

local ok, err = red:set("liguibing", "hello word5555788")
local ok2,err = red:get("liguibing")

ngx.header.content_type = "text/html"
ngx.say(sy_wa_redis_config_dev,ok2)
ngx.exit(ngx.HTTP_FORBIDDEN)
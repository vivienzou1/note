--全局规则配置

--总开关，是否启用waf,on or off(这里必须设置为on，建议在rule_conf下的base.json文件配置)
soyoung_waf_switch = "on"

--环境，用来控制redis的connect, dev or product
sy_wa_redis_config_dev = "dev"

-- 验证码调整解封地址
sy_captcha_jump_url = "http://wafcaptcha.soyoung.com:8001/capthcha/index.php?"

-- redis key配置, sy_md5_token_captcha_+ip
sy_md5_token_captcha = "waf:captcha:"

--规则存放目录
RulePath = "/opt/openresty/nginx/conf/waf/rule_conf/"

--- base.json 文件绝对路径 [需要自行根据自己服务器情况设置]
base_rule_json = "/opt/openresty/nginx/conf/waf/rule_conf/base.json"

-- 状态码
sy_error_code_100	= "100"
sy_error_code_200	= "200"
sy_error_code_301	= "301"
sy_error_code_403	= "403"
sy_error_code_404	= "404"
sy_error_code_502	= "502"
sy_error_code_503	= "503"


--恶意参数拦截提示
waf_show_error_html = [[
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>新氧美容整形</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
    body {margin:0;padding:0;font-size:14px;line-height:1.231;color:#555;text-align:center;font-family:"\5fae\8f6f\96c5\9ed1","\9ed1\4f53",tahoma,arial,sans-serif;}
    a {color:#555;text-decoration:none;}
    a:hover {color:#1abc9c;}
    #container {width:684px;height:315px;margin:100px auto 0px auto;border:#2c3e50 solid 6px;background-color:#2c3e50;}
    #container #title {overflow:hidden; padding-top:30px;}
    #container #title h1 {font-size:36px;text-align:center;color:#FFFFFF;}
    #content p{ font-size:18px;}
    #footer {width:100%;padding:20px 0px;font-size:16px;color:#555;text-align:center;}
    </style>
</head>

<body>
<div id="container">
<div id="title"><h1>Soyoung Service Access Denied</h1></div>
<div id="content">
<p>
<a href="http://www.soyoung.com" style="color:#4682B4"><b>返回首页</b></a></p>
<br />
<p style="font-size:24px;font-weight:bold;color:#1abc9c">Tips：请检查您的访问是否合法或联系客服</p>
</div>
</div>
    <div id="footer">
   &copy;2018
   <a href="http://www.soyoung.com" target="_blank">Soyoung</a> All rights reserved.
  </div>
</body>
</html>
]];

--封禁提示
waf_show_deny_error_html_header = [[
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>新氧美容整形</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
    body {margin:0;padding:0;font-size:14px;line-height:1.231;color:#555;text-align:center;font-family:"\5fae\8f6f\96c5\9ed1","\9ed1\4f53",tahoma,arial,sans-serif;}
    a {color:#555;text-decoration:none;}
    a:hover {color:#1abc9c;}
    #container {width:684px;height:315px;margin:100px auto 0px auto;border:#2c3e50 solid 6px;background-color:#2c3e50;}
    #container #title {overflow:hidden; padding-top:30px;}
    #container #title h1 {font-size:36px;text-align:center;color:#FFFFFF;}
    #content p{ font-size:18px;}
    #footer {width:100%;padding:20px 0px;font-size:16px;color:#555;text-align:center;}
    </style>
</head>

<body>
<div id="container">
<div id="title"><h1>Soyoung Service Access Denied</h1></div>
<div id="content">
<p>
]];

--封禁提示
waf_show_deny_error_html_foot = [[
</p><br />
<p style="font-size:24px;font-weight:bold;color:#1abc9c">Tips：请检查您的访问是否合法或联系客服</p>
</div>
</div>
    <div id="footer">
   &copy;2018
   <a href="http://www.soyoung.com" target="_blank">Soyoung</a> All rights reserved.
  </div>
</body>
</html>
]];
require 'waf_conf'

local config = {}
local require = require
local cjson_safe = require "cjson.safe"
local ngx_shared = ngx.shared
local io_open = io.open
local table_insert = table.insert
local ipairs = ipairs

--- base.json 文件绝对路径 [需要自行根据自己服务器情况设置]
local base_json = base_rule_json

--- 将全局配置参数存放到共享内存（*_dict）中
local config_dict = ngx_shared.config_dict
local host_dict = ngx_shared.host_dict
local ip_dict = ngx_shared.ip_dict

--- 读取文件（全部读取/按行读取）
--- loadjson()调用
local function readfile(_filepath,_ty)
    local fd = io_open(_filepath,"r")
    if fd == nil then return end
    if _ty == nil then
        local str = fd:read("*a") --- 全部内容读取
        fd:close()
        return str
    else
        local line_s = {}
        for line in fd:lines() do
            line = string.gsub(line,"^%s*(.-)%s*$", "%1")
            line = string.gsub(line, "\r", "")
            table_insert(line_s, line)
        end
        fd:close()
        return line_s
    end
end

--- 载入JSON文件
--- loadConfig()调用
local function loadjson(_path_name)
    local x = readfile(_path_name)
    local json = cjson_safe.decode(x) or {}
    return json
end

--- split 函数，暂时未使用  lua-resty-core
local function split(inputstr, sep)
    sep = sep or "%s"
    local t={} ; i=1
    for str in string_gmatch(inputstr, "([^"..sep.."]+)") do
        t[i] = str
        i = i + 1
    end
    return t
end

--- 载入config.json全局基础配置
--- 唯一一个全局函数
function loadConfig()

    config.base = loadjson(base_json)
    local _basedir = config.base.jsonPath or RulePath

    -- STEP 0

    -- STEP 1
    --- 将ip_mod放入 ip_dict 中
    local allowIpList = readfile(_basedir.."ip/allow.ip",true)
    local denyIpList = readfile(_basedir.."ip/deny.ip",true)
    local logIpList = readfile(_basedir.."ip/log.ip",true)
    for _,v in ipairs(allowIpList) do
        v = string.gsub(v, "^%s*(.-)%s*$", "%1")
        ip_dict:safe_set(v,"allow",0,0)
    end
    for _,v in ipairs(denyIpList) do
        v = string.gsub(v, "^%s*(.-)%s*$", "%1")
        ip_dict:safe_set(v,"deny",0,0)
    end
    for _,v in ipairs(logIpList) do
        v = string.gsub(v, "^%s*(.-)%s*$", "%1")
        ip_dict:safe_set(v,"log",0,0)
    end

    --将白名单host放入 ip_dict ，这些host请求将跳过规则，请谨慎添加
    local whiteHostList = readfile(_basedir.."host/white.host",true)
    for _,v in ipairs(whiteHostList) do
        host_dict:safe_set(v,"allow",0,0)
    end

    -- STEP 2

    -- STEP 3 rewrite_Mod

    -- STEP 4
    --- 读取host规则json 到host_dict

    -- STEP 5 - 14
    config.uri_Mod = loadjson(_basedir.."uri_Mod.json")
    config.cookie_Mod = loadjson(_basedir.."cookie_Mod.json")
    config.args_Mod = loadjson(_basedir.."args_Mod.json")
    config.post_Mod = loadjson(_basedir.."post_Mod.json")
    config.network_Mod = loadjson(_basedir.."network_Mod.json")
    config.networkurl_Mod = loadjson(_basedir.."networkurl_Mod.json")

    -- denyMsg list
    config.denyMsg = loadjson(_basedir.."denyMsg.json")

    -- 后续 整个config放到一个key中，不再分开，减少acc阶段序列化次数
    config_dict:safe_set("config",cjson_safe.encode(config),0)
    config_dict:safe_set("config_version","0.1",0)

end

loadConfig()

-- G_filehandler = io_open(config.base.logPath..(config.base.log_conf.filename or "waf.log"),"a+")
--G_filehandler = io_open(config.base.logPath..ngx.today()..(config.base.log_conf.filename or "waf.log"),"a+")
G_filehandler = io_open(config.base.logPath.."sy"..(config.base.log_conf.filename or "sy_waf.log"),"a+")

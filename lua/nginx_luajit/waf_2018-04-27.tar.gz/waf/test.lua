local cjson_safe = require "cjson.safe"
local optl = require("optl")
local JSON = require("xy_json")

--
local redis = require "redis_iresty"
local red = redis:new()

--local ok, err = red:set("liguibing", "hello liguibing")
redis:setex("liguibing",20,"hello liguibing tm")
local ok2,err = red:get("lgb_ip_test_a")


--获取过期时间
local _lip = "123.456.567.678"
local ip_dict_xxx = ngx.shared.ip_dict
ip_dict_xxx:safe_set(_lip,"test tm",60,80)

local gip_dict = ngx.shared["ip_dict"]
local ret,v = gip_dict:get(_lip)

--ndk.set_var.set_quote_sql_str("dskff")))

ngx.header.content_type = "text/html"
ngx.say(ngx.time(),"<hr>",ngx.now())
ngx.exit(ngx.HTTP_FORBIDDEN)


local xy_token = optl.set_user_browse_ip_token("key");
local token = optl.set_user_redis_data(xy_token,"lgb test")
local ok2,err = red:get(xy_token)

ngx.header.content_type = "text/html"
ngx.say(xy_token,"<hr>",ok2)
ngx.exit(ngx.HTTP_FORBIDDEN)





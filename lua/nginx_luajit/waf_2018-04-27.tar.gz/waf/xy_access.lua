local optl = require("optl")
local ngx_var = ngx.var
local ngx_ctx = ngx.ctx
local ngx_unescape_uri = ngx.unescape_uri
local config = optl.config
local config_base = config.base or {}

local limit_ip_dict = ngx.shared.limit_ip_dict
local ip_dict = ngx.shared.ip_dict
local host_dict = ngx.shared.host_dict
local limit_dict = ngx.shared.limit

-- 唯一 request_id
local next_ctx = {request_guid = ngx_var.request_id}
ngx_ctx.next_ctx = next_ctx

-- 获取所有参数的内容
	--获取用户ip，有代理
	local remoteIp = ngx_var.http_x_forwarded_for
	if remoteIp == nil then
		-- 没有代理的时候用remote_addr获取用户的真实ip
		remoteIp = ngx_var.remote_addr
	end
	--local ip = remoteIp
	local ip = optl.getClientIp(remoteIp)

	local host = ngx_unescape_uri(ngx_var.http_host)
	local method = ngx_var.request_method
	local request_uri = ngx_unescape_uri(ngx_var.request_uri)
	local uri = ngx_unescape_uri(ngx_var.uri)
	local useragent = ngx_unescape_uri(ngx_var.http_user_agent)
	local referer = ngx_unescape_uri(ngx_var.http_referer)
	local cookie = ngx_unescape_uri(ngx_var.http_cookie)
	local query_string = ngx_unescape_uri(ngx_var.query_string)

	local headers = ngx.req.get_headers()
	local headers_data
	local function tmp_pcall()
		headers_data = ngx_unescape_uri(ngx.req.raw_header(false))
	end
	pcall(tmp_pcall)
	local http_content_type = ngx_unescape_uri(ngx_var.http_content_type)

	local args = ngx.req.get_uri_args()
	local args_data = optl.get_table(args)

	local posts = {}
	local posts_data = ""
	local posts_all
	if method == "POST" and http_content_type then
		-- multipart/form-data; boundary=----WebKitForm...
		-- local from,to = string.find(http_content_type,"x-www-form-urlencoded",1,true)
		local from,to = string.find(http_content_type,"multipart/form-data",1,true)
		if from then
			posts = ngx.req.get_post_args()
			posts_data = optl.get_table(posts)
		end
	end

local base_msg = {}
	-- string 类型http参数
	base_msg.remoteIp = remoteIp
	base_msg.host = host
	base_msg.ip = ip
	base_msg.method = method
	base_msg.request_uri = request_uri
	base_msg.uri = uri
	base_msg.useragent = useragent
	base_msg.referer = referer
	base_msg.cookie = cookie
	base_msg.query_string = query_string

	-- table 类型参数
	base_msg.headers = headers
	base_msg.args = args
	base_msg.posts = posts

	-- table_str
	base_msg.headers_data = headers_data
	base_msg.args_data = args_data
	base_msg.posts_data = posts_data

next_ctx.base_msg = base_msg

local current_time_tamp = ngx.now()
local host_Mod_state = host_dict:get(host)

--- waf增加全局Mod开关
if config_base.Mod_state == "off" or host_Mod_state == "off" or soyoung_waf_switch == "off" then
	return
end

--- 判断config_dict中模块开关是否开启
local function config_is_on(_config_arg)
    if config_base[_config_arg] == "on" then
        return true
    end
    -- return config_base[_config_arg] == "on"
end

--- 取config_dict中的json数据
local function getDict_Config(_Config_jsonName)
    local re = config[_Config_jsonName] or {}
    return re
    -- return (config[_Config_jsonName] or {})
end

--- remath_ext 是 remath_Invert(str,re_str,options,true) 的扩展
local function remath_ext(str,remath_rule)
	if type(remath_rule) ~= "table" then return false end
	if optl.remath_Invert(str,remath_rule[1],remath_rule[2],remath_rule[3]) then
		return true
	end
	-- return optl.remath_Invert(str,remath_rule[1],remath_rule[2],remath_rule[3])
end

--- 匹配 host 和 uri
local function host_uri_remath(_host,_uri)
	--先屏蔽，减少正则匹配

	return true
	--[[if remath_ext(host,_host) and remath_ext(uri,_uri) then
		return true
	end--]]
end

--- 拦截计数 ， 从全局变成local
local set_count_dict = optl.set_count_dict

-- 唯一token标识
local xy_way_token = sy_md5_token_captcha..ip

local action_tag = ""
local function action_deny(_flag)
	action_tag = "deny"

	--验证码页面不限制
	if uri == "/api/ip_dict" or uri == "/capthcha/check.php" or uri == "/capthcha/index.php" or uri =="/capthcha/code.php" then
		return
	end

	--如果是ip封禁，修改提示页面内容(用户通过图片验证码自行解封)
	if _flag == "deny" then
		local _xy_token = optl.get_user_browse_ip_token(xy_way_token)
		waf_show_error_html = waf_show_deny_error_html_header..optl.getUnlockCaptchaJumpUrl(xy_way_token)..waf_show_deny_error_html_foot
	end

	-- 增加Mod_state = log , host_Mod state = log
	-- 在拒绝请求都进行了log记录，仅ip黑名单的没有记录（因为量的问题），故可直接return
	if config_base.Mod_state == "log" or host_Mod_state == "log" then
		return
	end
	if config_base.denyMsg.state == "on" then
		local tb = getDict_Config("denyMsg")
		local host_deny_msg = tb[host] or {}
		local tp_denymsg = type(host_deny_msg.deny_msg)
		if tp_denymsg == "number" then
			ngx.exit(waf_show_error_html)
		elseif tp_denymsg == "string" then
			ngx.header.content_type = "text/html"
			ngx.say(waf_show_error_html)
			ngx.exit(200)
		end
	end
	if type(config_base.denyMsg.msg) == "number" then
		ngx.exit(waf_show_error_html)
	else
		ngx.header.content_type = "text/html"
		ngx.say(waf_show_error_html)
		ngx.exit(200)
	end
end

-- action = {allow,deny,log}
local function do_action(_action,_mod_name,_id,_obj)

	_id = _id or tostring(_id)
	if _action == "allow" then
		return true
	elseif _action == "deny" then
		--这个数可以用于如 按拦截次数确定是否封禁的一个指标
		set_count_dict(_mod_name.."_deny_count")
		next_ctx.waf_log = next_ctx.waf_log or "mod[".._mod_name.."],ip["..ip.."],deny No: ".._id

		-- post请求参数log
		--[[
		if type(method) == "string" and method == "POST" then
			next_ctx.waf_log = posts_data
			next_ctx.waf_log = next_ctx.waf_log or "[".._mod_name.."] log No: ".._id
			action_deny()
			return false
		end
		--]]

		action_deny()
		return false
	elseif _action == "log" then
		set_count_dict(_mod_name.."_log_count")
		next_ctx.waf_log = next_ctx.waf_log or "[".._mod_name.."] log No: ".._id
	end
end

-- 获取post_form表单数据
local function get_post_form(_len)
	if _len <= 0 then _len = nil end
	posts_all = posts_all or optl.get_post_all()
	base_msg.posts_all = posts_all
    local parser = require "bodyparser"
    local p, err = parser.new(posts_all, http_content_type,_len)
    if p then
		local tmp_tb = {}
	    while true do
	       local part_body, name, mime, filename = p:parse_part()
	       if not part_body then
	          break
	       end
	       table.insert(tmp_tb, {name,filename,mime,part_body})
	    end
	    base_msg.post_form = tmp_tb
    end
end

--封ip自助解封token设置,IP,有效时间
local function set_sy_lock_user_ip_info(_ip,_tm)
	if _ip == nil then
		_ip = ip
	end

	if _tm == nil then
		_tm = 3600
	end

	optl.set_user_redis_data(_ip,_tm)

	return
end

-- START STEP RULE.......

--host white dict
local white_host = host_dict:get(host)
if white_host == "allow" then
	return
end

-- ip 访问控制
if config_is_on("ip_Mod") then
	local _ip_v = ip_dict:get(ip) --- 全局IP 黑白名单

	--拦截标识，通过这个标识提示不同的拦截页面
	local _ip_deny = "deny"

	if _ip_v == nil then
		-- nothing
	elseif _ip_v == "allow" then -- 跳出后续规则
		return
	elseif _ip_v == "log" then
		set_count_dict(ip.." log count")
 		--next_ctx.waf_log = "[ip_Mod] log"
	else
		next_ctx.waf_log = "[ip_Mod] ip["..ip.."] deny"
		set_count_dict(ip)
		action_deny(_ip_deny)
	end

	-- 基于host的ip黑白名单 eg:www.abc.com_101.111.112.113
	local tmp_host_ip = host.."_"..ip
	local host_ip = ip_dict:get(tmp_host_ip)

	if host_ip == nil then
		-- nothing
	elseif host_ip == "allow" then -- 跳出后续规则
		return
	elseif host_ip == "log" then
		set_count_dict(tmp_host_ip.." log count")
 		--next_ctx.waf_log = "[host_ip_Mod] log"
	else
		next_ctx.waf_log = "[host_ip_Mod] deny"
		set_count_dict(tmp_host_ip)
		action_deny(_ip_deny)
	end
end

-- uri 黑白名单
if config_is_on("uri_Mod") and action_tag == "" then
	local uri_mod = getDict_Config("uri_Mod")
	for i, v in ipairs( uri_mod ) do
		if v.state == "on" and remath_ext(uri,v.uri) then
			local _action = v.action or "deny"
			if do_action(_action,"uri_Mod",i) == true then
				return
			elseif do_action(_action,"uri_Mod",i) == false then
				break
			elseif do_action(_action,"uri_Mod",i) == nil then
				-- continue
			end
		end
	end
end

-- cookie
if config_is_on("cookie_Mod") and action_tag == "" then
	local cookie_mod = getDict_Config("cookie_Mod")
	for i, v in ipairs( cookie_mod ) do
		if v.state == "on" and remath_ext(host,v.hostname) and remath_ext(cookie,v.cookie) then
			local _action = v.action or "deny"
			if do_action(_action,"cookie_Mod",i) == true then
				return
			elseif do_action(_action,"cookie_Mod",i) == false then
				break
			elseif do_action(_action,"cookie_Mod",i) == nil then
				-- continue
			end
		end
	end
end

-- args
if config_is_on("args_Mod") and action_tag == "" then
	local args_mod = getDict_Config("args_Mod")
	for i,v in ipairs(args_mod) do

		if v.state == "on" and remath_ext(host,v.hostname) and remath_ext(args_data,v.args_data) then
			local _action = v.action or "deny"
			if do_action(_action,"args_Mod",i) == true then
				return
			elseif do_action(_action,"args_Mod",i) == false then
				break
			elseif do_action(_action,"args_Mod",i) == nil then
				-- continue
			end
		end
	end
end

-- post
if config_is_on("post_Mod") and action_tag == "" then
	local post_mod = getDict_Config("post_Mod")
	for i,v in ipairs(post_mod) do
		if v.state == "on" and remath_ext(host,v.hostname) and remath_ext(posts_data,v.posts_data) then
			local _action = v.action or "deny"
			if do_action(_action,"post_Mod",i) == true then
				return
			elseif do_action(_action,"post_Mod",i) == false then
				break
			elseif do_action(_action,"post_Mod",i) == nil then
				-- continue
			end
		end
	end
end

-- networkurl_Mod 控制访问某个具体的url的频率,达到阀值封整站
if config_is_on("networkurl_Mod") and action_tag == "" then
	local tb_networkUrlMod = getDict_Config("networkurl_Mod")
	local netUrlToken = ip..uri
	for i, v in ipairs(tb_networkUrlMod) do
		if v.state =="on" and host_uri_remath(v.hostname,v.uri) then
        	local reqUrlCount,_ = limit_dict:get(netUrlToken)
			local pTime =  v.network.pTime or 60
			local blacktime = v.network.blackTime or 120
			-- 获取封禁次数，如果需要彻底解封，需要单独调用 optl.deleteCountDict(ip) 删除
			-- 否则后续封禁时长会一直呈递增方式
			local cntIp = optl.getCountDict(ip)
			local lockTmpCnt = optl.get_random_num(cntIp*10,cntIp*100)
			if cntIp < 3 then
				--前三次只封禁1分钟
				lockTmpCnt = 0
			end
			blacktime = blacktime + lockTmpCnt
			--封禁时间最多1天
			if blacktime > 864000 then
				blacktime = 864000
			end
			--blacktime = 60

        	if reqUrlCount then
        		local maxReqs = v.network.maxReqs or 60
        		if reqUrlCount > maxReqs then
        			--设置锁定标识-用户自助解除封禁使用，图片验证码
					set_sy_lock_user_ip_info(xy_way_token,blacktime)

        			-- netUrlToken = netUrlToken.."_deny"
        			local lock_network_mod_log_info = "key["..netUrlToken.."],mod["..ip.."],blacktime["..pTime.."]"
                	ip_dict:safe_set(ip,netUrlToken,blacktime,current_time_tamp+blacktime)
                	next_ctx.waf_log = lock_network_mod_log_info.."[networkurl_Mod] deny  No: "..i
					action_deny()
	            else
	                limit_dict:incr(netUrlToken,1)
	            end
        	else
        		limit_dict:set(netUrlToken,1,pTime)
        	end
		end
	end
end

-- network_Mod 访问控制(ip),封禁全站
if config_is_on("network_Mod") and action_tag == "" then
	local tb_networkMod = getDict_Config("network_Mod")
	for i, v in ipairs(tb_networkMod) do
		if v.state =="on" and host_uri_remath(v.hostname,v.uri) then
			local mod_ip = ip.."_network_mod_"..i
			local ip_count = limit_ip_dict:get(mod_ip)

			if ip_count == nil then
				local pTime =  v.network.pTime or 10
				limit_ip_dict:set(mod_ip,1,pTime)
			else
				local lock_network_mod_log_info = ""
				local maxReqs = v.network.maxReqs or 50
				if ip_count >= maxReqs then
					local blacktime = v.network.blackTime or 120
					-- 获取封禁次数，如果需要彻底解封，需要单独调用 optl.deleteCountDict(ip) 删除
					-- 否则后续封禁时长会一直呈递增方式
					local cntIp = optl.getCountDict(ip)
					local lockTmpCnt = optl.get_random_num(cntIp*10,cntIp*100)
					if cntIp < 3 then
						--前三次只封禁1分钟
						lockTmpCnt = 0
					end
					blacktime = blacktime + lockTmpCnt
					--封禁时间最多1天
					if blacktime > 864000 then
						blacktime = 864000
					end
					--blacktime = 60

					--设置锁定标识-用户自助解除封禁使用，图片验证码
					set_sy_lock_user_ip_info(xy_way_token,blacktime)

					--locak ip
					if v.hostname[2] == "" then
						if v.hostname[1] == "*" then
							lock_network_mod_log_info = "key["..ip.."],mod["..mod_ip.."],blacktime["..blacktime.."]"
							ip_dict:safe_set(ip,mod_ip,blacktime,current_time_tamp+blacktime)
						else
							lock_network_mod_log_info = "key["..host.."-"..ip.."],ip["..ip.."],mod["..mod_ip.."],blacktime["..blacktime.."]"
							ip_dict:safe_set(host.."-"..ip,mod_ip,blacktime,current_time_tamp+blacktime)
						end
					elseif v.hostname[2] == "table" then
						for j,vj in ipairs(v.hostname[1]) do
							lock_network_mod_log_info = "key["..vj.."-"..ip.."],ip["..ip.."],mod["..mod_ip.."],blacktime["..blacktime.."]"
							ip_dict:safe_set(vj.."-"..ip,mod_ip,blacktime,current_time_tamp+blacktime)
						end
					elseif v.hostname[2] == "list" then
						for j,vj in pairs(v.hostname[1]) do
							lock_network_mod_log_info = "key["..ip.."],ip["..ip.."],mod["..mod_ip.."],blacktime["..blacktime.."]"
							ip_dict:safe_set(j.."-"..ip,mod_ip,blacktime,current_time_tamp+blacktime)
						end
					else
						lock_network_mod_log_info = "key["..host.."-"..ip.."],ip["..ip.."],mod["..mod_ip.."],blacktime["..blacktime.."]"
						ip_dict:safe_set(host.."-"..ip,mod_ip,blacktime,current_time_tamp+blacktime)
					end
					next_ctx.waf_log = lock_network_mod_log_info.."[network_Mod] deny  No: "..i
					action_deny()
					--ngx.say("frist network deny")
					break
				else
				    limit_ip_dict:incr(mod_ip,1)
				end
			end

		end
	end
end

